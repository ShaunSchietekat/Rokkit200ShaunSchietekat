﻿namespace Rokkit200
{


    public class SystemDB
    {
        public class AccountData
        {
            public int id { get; set; }
            public int customerNum { get; set; }
            public int balance { get; set; }
            public int overdraft { get; set; }

        }
        private static SystemDB uniqInstance;
        public List<AccountData> accData = new List<AccountData>();
        public SystemDB()
        {
            accData.AddRange(new List<AccountData>
            {
                new AccountData{
                    id = 1,
                    customerNum = 1,
                    balance = 2000,
                    overdraft = 0
                },
                new AccountData{
                    id = 1,
                    customerNum = 2,
                    balance = 5000,
                    overdraft = 0
                },
                new AccountData{
                    id = 2,
                    customerNum = 3,
                    balance = 1000,
                    overdraft = 10000
                },
                new AccountData{
                    id = 2,
                    customerNum = 4,
                    balance = -5000,
                    overdraft = 20000
                }
            });
        }

        public static SystemDB getInstance()
        {
            if (uniqInstance == null)
                uniqInstance = new SystemDB();
            return uniqInstance;
        }
        public List<AccountData> getData(int custNum)
        {
            return this.accData.Where(x=>x.customerNum == custNum).ToList();

        }
        public void UpdateData(AccountData accountData)
        {
            var test = this.accData.Where(x => x.customerNum == accountData.customerNum).FirstOrDefault();

            test.balance = accountData.balance;
        }
    }
}
