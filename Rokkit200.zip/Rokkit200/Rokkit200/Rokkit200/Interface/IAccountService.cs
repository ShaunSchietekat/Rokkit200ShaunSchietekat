﻿namespace Rokkit200.Interface
{
    public interface IAccountService
    {
        //public void openSavingsAccount(Long accountId, Long amountToDeposit);
        //public void openCurrentAccount(Long accountId);
        public void withdraw(int accountId, int amountToWithdraw);
        //throws AccountNotFoundException, WithdrawalAmountTooLargeException;
        public void deposit(int accountId, int amountToDeposit);
        //throws AccountNotFoundException;
    }
}
