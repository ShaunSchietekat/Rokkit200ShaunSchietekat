﻿using Rokkit200.Interface;

namespace Rokkit200.Models
{
    public class CurrentAccount : Account,IAccountService
    {
        public SystemDB db = SystemDB.getInstance();
        public int overdraft { get; set; }

        public CurrentAccount(int overdraft)
        {
            this.overdraft = overdraft;
        }

        public void deposit(int accountId, int amountToDeposit)
        {

            var cusData = db.accData.Where(x => x.customerNum == accountId).FirstOrDefault();
            cusData.balance = cusData.balance + amountToDeposit;
        }

        public void withdraw(int accountId, int amountToWithdraw)
        {
            var cusData = db.accData.Where(x => x.customerNum == accountId).FirstOrDefault();
            cusData.balance = cusData.balance - amountToWithdraw;
        }
    }
}
