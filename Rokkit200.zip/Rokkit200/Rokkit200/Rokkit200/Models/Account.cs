﻿namespace Rokkit200.Models
{
    public class Account
    {
        public int customerNum { get; set; }
        public int balance { get; set; }
    }
}
