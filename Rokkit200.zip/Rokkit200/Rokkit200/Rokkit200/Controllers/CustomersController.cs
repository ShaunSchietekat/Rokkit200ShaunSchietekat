﻿using Microsoft.AspNetCore.Mvc;
using Rokkit200.Service;

namespace Rokkit200.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        [HttpPost]
        [Route("{custNum}/{TransactionType}/{Amount}")]
        public string Transaction(int custNum,int TransactionType, int Amount)
        {
            
            AccountService accountService = new AccountService();
            return accountService.AccountQuery(custNum,TransactionType, Amount);

        }
    }
}
