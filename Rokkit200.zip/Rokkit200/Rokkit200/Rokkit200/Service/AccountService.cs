﻿using Rokkit200.Models;
using System.Text;

namespace Rokkit200.Service
{
    public class AccountService
    {
        public string AccountQuery(int custNum, int tt, int Amount)
        {
            var returnStr = new StringBuilder();
            SystemDB db = SystemDB.getInstance();
            var AccountInfo = db.getData(custNum).Select(x => x).FirstOrDefault();

            if(AccountInfo == null)
            {
                return returnStr.AppendLine("CustomerNum does not exist").ToString();
            }
            if (AccountInfo.id == 1)
            {
                SavingsAccount savingsAccount = new SavingsAccount();
                if (tt == 1)
                {
                    if (Amount > AccountInfo.balance)
                    {
                        return returnStr.AppendLine("Insufficient funds (current balance : " + AccountInfo.balance + ")").ToString();
                    }
                    else
                    {
                        savingsAccount.withdraw(custNum, Amount);
                    }

                }
                else if (tt == 2)
                {
                    savingsAccount.deposit(custNum, Amount);
                }
                else
                {
                    return returnStr.AppendLine("TransactionType can only be 1(Withdraw) or 2(Deposit)").ToString();
                }

            }
            else if (AccountInfo.id == 2)
            {
                CurrentAccount currentAccount = new CurrentAccount(AccountInfo.overdraft);
                if (tt == 1)
                {
                    if (Amount > AccountInfo.balance + AccountInfo.overdraft)
                    {
                        return returnStr.AppendLine("Insufficient funds (current balance : " + AccountInfo.balance + " , overdraft : " + AccountInfo.overdraft + ")").ToString();
                    }
                    else
                    {
                        currentAccount.withdraw(custNum, Amount);
                    }

                }
                else if (tt == 2)
                {
                    currentAccount.deposit(custNum, Amount);
                }
                else
                {
                    return returnStr.AppendLine("TransactionType can only be 1(Withdraw) or 2(Deposit)").ToString();
                }
            }
            else
            {
                return returnStr.AppendLine("Account dos not exist 1(Savings) and 2(Current)").ToString();
            }

            return returnStr.AppendLine("CustomerNum : " + AccountInfo.customerNum + " Balance : " + AccountInfo.balance).ToString();

        }
    }
}
